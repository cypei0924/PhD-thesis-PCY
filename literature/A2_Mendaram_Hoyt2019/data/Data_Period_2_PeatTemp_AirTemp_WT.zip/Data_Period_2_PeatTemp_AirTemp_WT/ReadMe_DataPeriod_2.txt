Supporting data files for:
Hoyt, A. M., Gandois, L. , Eri, J. , Kai, F. M., Harvey, C. F. and Cobb, A. R. (2019), 
CO2 emissions from an undrained tropical peatland: Interacting influences of temperature, shading and water table depth. 
Global Change Biology. doi:10.1111/gcb.14702

Link: https://doi.org/10.1111/gcb.14702

Data Period 2: (Nov 24, 2013 - Mar 23, 2014)
-These files include data presented in Figure 4, Figure 5, and Figure S2.

Units:
 -Water table depth is reported in meters. Negatives indicate depths below the peat surface.
 -Air temperature is reported in degrees C.
 -Peat temperature is reported in degrees C.
 
 Files:
 
 Peat temperature:
 -PeatTemperature_Tiddbits_Period_2.csv
 -This file includes peat temperatures measured in the sun and shade, at the surface, 10cm depth, and 25cm depth. 
 
 Water table depth:
 -WaterTable_Period_2.csv
 
 Air temperature:
 -AirTemp_Period_2.csv
 
 

 
 
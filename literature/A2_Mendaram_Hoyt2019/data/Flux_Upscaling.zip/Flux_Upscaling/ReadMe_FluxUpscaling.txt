Supporting data files for:
Hoyt, A. M., Gandois, L. , Eri, J. , Kai, F. M., Harvey, C. F. and Cobb, A. R. (2019), 
CO2 emissions from an undrained tropical peatland: Interacting influences of temperature, shading and water table depth. 
Global Change Biology. doi:10.1111/gcb.14702

Link: https://doi.org/10.1111/gcb.14702

Flux Upscaling: (Feb 6, 2012 - Feb 6, 2015)
-These files include data presented in Figure 3.
-Time series of calculated fluxes are presented in Fig 3a.
-Flux vs. water table relationships used for upscaling are presented in Fig 3b.
(Daily mean data presented in Fig 3b is included with files from data period 1.)
-The water table time series used for upscaling is presented in Fig 3c.

Units:
 -C fluxes are reported in micromol/m^2/s.
 -Water table depth is reported in meters. Negatives indicate depths below the peat surface.
 
 Files:
 
 Upscaling time series (Fig 3a & 3c):
 -UpscalingTimeseries_3yrs.csv
 
 Relationships used for upscaling (Fig 3b):
 -Rhet_WT_Upscaling_Relationship.csv
 (includes both Rhet from hollows and the dome-wide Rhet)
 -DOC_WT_Upscaling_Relationship.csv
 

 
 

 
 
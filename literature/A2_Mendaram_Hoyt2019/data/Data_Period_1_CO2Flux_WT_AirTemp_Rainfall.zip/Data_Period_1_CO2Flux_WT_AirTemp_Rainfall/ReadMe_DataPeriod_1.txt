Supporting data files for:
Hoyt, A. M., Gandois, L. , Eri, J. , Kai, F. M., Harvey, C. F. and Cobb, A. R. (2019), 
CO2 emissions from an undrained tropical peatland: Interacting influences of temperature, shading and water table depth. 
Global Change Biology. doi:10.1111/gcb.14702

Link: https://doi.org/10.1111/gcb.14702

Data Period 1: (Jul 13 - Nov 23, 2012)
-These files include data presented in Figure 2 and Figure S1.
-Daily means are also presented in Figure 3b.
-Period 1a includes Jul-Aug when Chambers 1 & 4 were operating. 
-Period 1b includes Aug-Nov when Chambers 1,2,3 & 4 were operating. 
-Instrument failure in Oct resulted in a shorted time series for Chamber 2.

Units:
 -CO2 fluxes are reported in micromol/m^2/s.
 -Water table depth is reported in meters. Negatives indicate depths below the peat surface.
 -Air temperature is reported in degrees C.
 -Rain depth is reported in mm. 
 
 Files:
 
 CO2 Fluxes:
 -CO2flux_Chamber1_Sun_Period_1a.csv
 -CO2flux_Chamber1_Sun_Period_1b.csv
 -CO2flux_Chamber2_Shade_Period_1b.csv
 -CO2flux_Chamber3_Shade_Period_1b.csv
 -CO2flux_Chamber4_Shade_Period_1a.csv
 -CO2flux_Chamber4_Shade_Period_1b.csv
 
 Water table depth:
 -WaterTable_Period_1a.csv
 -WaterTable_Period_1b.csv
 
 Air temperature:
 -AirTemp_Period_1extended.csv
 
 Rainfall: 
 -RainDepth_Period_1.csv
 
 Daily mean values of CO2 flux across all chambers, water table and air temperature:
 -DailyMeans_Period_1b.csv
 
  

 
 